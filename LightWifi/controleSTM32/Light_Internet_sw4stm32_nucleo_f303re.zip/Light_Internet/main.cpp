#include "mbed.h"

DigitalOut led1(LED1);
DigitalOut d7(D7);
DigitalIn d10(D10);

int notNumber(int number) {
 if(number == 0) {
     return 1;
  } else {
     return 0;
  }
}

int main() {
    int lampadaLigada = notNumber(d10);
    d7 = lampadaLigada;
    led1 = lampadaLigada;
    while (true) {
       int ligarLampada = notNumber(d10);
       if (ligarLampada != lampadaLigada) {
            d7 = ligarLampada;
            led1 = ligarLampada;
            lampadaLigada = ligarLampada;
       }
    }
}

